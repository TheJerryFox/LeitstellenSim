import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { io } from 'socket.io-client';

function MissionList({ onSelectMission }) {
    const [missions, setMissions] = useState([]);
    const [isLoading, setIsLoading] = useState(true);
    const [vehicles, setVehicles] = useState([]);

    useEffect(() => {
        const socket = io(process.env.REACT_APP_URL);
        
        axios.get('http://localhost:5000/api/missions')
            .then((response) => {
                setMissions(response.data);
                setIsLoading(false);
            })
            .catch((error) => {
                console.error('Fehler beim Abrufen der Einsätze:', error);
                setIsLoading(false);
            });

        axios.get('http://localhost:5000/api/vehicles')
            .then((response) => {
                setVehicles(response.data);
            })
            .catch((error) => {
                console.error('Fehler beim Abrufen der Fahrzeuge:', error);
            });

        socket.on('updateMissions', (data) => setMissions(data));
        socket.on('updateVehicles', (data) => setVehicles(data));
    }, []);

    return (
        <div>
            <h2>Einsätze</h2>
            {isLoading ? (
                <p>Wird geladen...</p>
            ) : (
                <ul>
                    {missions.map(mission => (
                        <li key={mission._id}>
                            <strong>{mission.description}</strong>
                            <br />
                            Ort: {mission.location.latitude}, {mission.location.longitude}
                            <br />
                            Status: {mission.status}
                            <br />
                            Benötigte Fahrzeuge: {mission.requiredVehicles.join(', ')}
                            <br />
                            Zugewiesene Fahrzeuge: {mission.assignedVehicles.map(v => {
                                const vehicle = vehicles.find(vehicle => vehicle._id === v);
                                return vehicle ? vehicle.name : "Unbekanntes Fahrzeug";
                            }).join(', ') || 'Keine'}
                            <br />
                            <button onClick={() => onSelectMission(mission)}>Ansehen</button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
}

export default MissionList;
